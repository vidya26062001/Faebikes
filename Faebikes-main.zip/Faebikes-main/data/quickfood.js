export default [
    {
        id:"0",
        image:"https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_264,h_288,c_fill/w1rrow27w3vb3ur5xbi9",
        name:"McDonald's",
        rating:4.3,
        time:"30-40",
        offer:"50%"
    },
    {
        id:"1",
        image:"https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_264,h_288,c_fill/ch07avzpos83wrfdfhyh",
        name:"Special Biriyani",
        rating:3.8,
        time:"30-40",
        offer:"60%"

    },
    {
        id:"2",
        image:"https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_264,h_288,c_fill/hiezygiuixjqjogg6w2b",
        name:"Hyderabadi Bawarchi",
        rating:4.1,
        time:"25-35",
        offer:"55%",
    },
    {
        id:"3",
        image:"https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_264,h_288,c_fill/q391dhemwszg9orhgldh",
        name:"Calofornia Burrito",
        rating:4.5,
        time:"20-30",
        offer:"30%"
    },
    {
        id:"4",
        image:"https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_112,h_112,c_fill/ei26sjhizcjrk9gmjy5r",
        name:"udupi Utsav",
        rating:4.3,
        time:"30-40",
        offer:"60%"
    }
]